﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class EditPanel : Form
    {
        public EditPanel(string id)
        {
            InitializeComponent();
            chosenId = id;
            btnStrawberry.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/strawberry.png");
            btnWatermelon.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/watermelon.png");
            btnMango.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/mango.png");
            btnGrapes.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/grapes.png");
            btnOrange.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/orange.png");

            btnCookies.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/cookies.png");
            btnWafer.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/wafer.png");
            btnChocolate.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/chocolate.png");
            btnBiscoff.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/biscoff.png");
            btnCandy.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/candy.png");
        }

        string chosenId;
        string dataPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/orders.txt";
        int limit;
        int height;
        private void EditPanel_Load(object sender, EventArgs e)
        {
            String[] entries;
            lblOrderNumber.Text = chosenId;

            using (StreamReader sr = new StreamReader(dataPath))
            {
                entries = sr.ReadToEnd().Split('>');
            }

            for (int i = 0; i < entries.Length - 1; i++)
            {
                String[] data = entries[i].Split(',');
                string Id = data[3];

                if (chosenId == Id)
                {
                    txtName.Text = data[0];
                    txtNumber.Text = data[1];
                    lblPrice.Text = data[2];
                    lblOrderNumber.Text = data[3];
                    cmbStatus.Text = data[4];
                    cmbPayment.Text = data[5];
                    cmbCupSize.Text = data[6].Trim();

                    if ( cmbCupSize.Text == "6 oz" )
                    {
                        limit = 6;
                        height = 40;
                    } else if ( cmbCupSize.Text == "8 oz" )
                    {
                        limit = 8;
                        height = 30;
                    } else if ( cmbCupSize.Text == "12 oz" )
                    {
                        limit = 12;
                        height = 20;
                    } else
                    {
                        limit = 16;
                        height = 15;
                    }

                    string[] layers = data[7].Split(':');

                    foreach ( string layer in layers)
                    {

                        int r, g, b;

                        if (layer == "STRAWBERRY")
                        {
                            r = 196;
                            g = 80;
                            b = 131;
                        }
                        else if (layer == "WATERMELON")
                        {
                            r = 227;
                            g = 115;
                            b = 131;
                        }
                        else if (layer == "MANGO")
                        {
                            r = 255;
                            g = 195;
                            b = 0;
                        }
                        else if (layer == "GRAPES")
                        {
                            r = 111;
                            g = 45;
                            b = 168;
                        }
                        else if (layer == "ORANGE")
                        {
                            r = 255;
                            g = 140;
                            b = 0;
                        }
                        else if (layer == "COOKIES")
                        {
                            r = 187;
                            g = 136;
                            b = 85;
                        }
                        else if (layer == "BISCOFF")
                        {
                            r = 224;
                            g = 163;
                            b = 121;
                        }
                        else if ( layer == "WAFER")
                        {
                            r = 228;
                            g = 192;
                            b = 141;
                        }
                        else if ( layer == "CHOCOLATE")
                        {
                            r = 123;
                            g = 63;
                            b = 0;
                        } 
                        else if ( layer == "CANDY" )
                        {
                            r = 0;
                            g = 191;
                            b = 255;
                        } else
                        {
                            continue;
                        }

                        Label lb = new Label();
                        lb.Size = new System.Drawing.Size(243, height);
                        lb.Margin = new Padding(0, 0, 0, 0);
                        lb.Text = layer;
                        lb.TextAlign = ContentAlignment.MiddleCenter;
                        lb.BorderStyle = BorderStyle.FixedSingle;
                        lb.BackColor = Color.FromArgb(r, g, b);
                        lb.ForeColor = Color.White;
                        lb.Cursor = Cursors.Hand;
                        lb.Click += (object lblSender, EventArgs lblE) =>
                        {
                            Control label = (Control)lblSender;
                            label.Parent.Controls.Remove(label);
                        };

                        flwOrder.Controls.Add(lb);

                    }
                }

            }

        }

        private void btnStrawberry_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "STRAWBERRY";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(190, 86, 131);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnWatermelon_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "WATERMELON";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(227, 115, 131);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnMango_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "MANGO";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(255, 195, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnGrapes_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "GRAPES";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(111, 45, 168);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnOrange_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "ORANGE";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(255, 140, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnCookies_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "COOKIES";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(187, 136, 85);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnBiscoff_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "BISCOFF";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(224, 163, 121);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnWafer_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "WAFER";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(228, 192, 141);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnChocolate_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "CHOCOLATE";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(123, 63, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnCandy_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "CANDY";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(0, 191, 255);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);

            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String[] entries;

            using (StreamReader sr = new StreamReader(dataPath))
            {
                entries = sr.ReadToEnd().Split('>');
            }

            using (StreamWriter sw = new StreamWriter(dataPath))
            {

                for (int i = 0; i < entries.Length - 1; i++)
                {
                    String[] data = entries[i].Split(',');
                    string Id = data[3];

                    if (chosenId != Id)
                    {
                        sw.WriteLine($"{data[0].Trim()}, {data[1].Trim()}, {data[2].Trim()}, {data[3].Trim()}, {data[4].Trim()}, {data[5].Trim()}, {data[6].Trim()}, {data[7]}>".Trim());
                    }

                }

                Visible = false;

            }

            using (StreamWriter sw_data = new StreamWriter(dataPath, append: true))
            {
                string name = txtName.Text.Trim();
                string number = txtNumber.Text.Trim();
                string price = lblPrice.Text.Trim();
                string orderNum = lblOrderNumber.Text.Trim();
                string status = cmbStatus.Text.Trim();
                string paymentMethod = cmbPayment.Text.Trim();
                string cupSize = cmbCupSize.Text.Trim();
                string layers = "END:".Trim();

                foreach (Control control in flwOrder.Controls)
                {
                    // Check if the control is a Label
                    if (control is Label label)
                    {
                        // Access the Text property of the Label
                        string labelText = label.Text;
                        layers += $"{labelText}:";
                    }
                }

                sw_data.WriteLine($"{name}, {number}, {price}, {orderNum}, {status}, {paymentMethod}, {cupSize}, {layers} >");
            }
        }

        private void cmbCupSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            flwOrder.Controls.Clear();

            int spaceIndex = cmbCupSize.Text.IndexOf(' '); 
            limit = int.Parse(cmbCupSize.Text.Substring(0, spaceIndex));

            if (limit == 6)
            {
                height = 40;
            }
            else if (limit == 8)
            {
                height = 30;
            }
            else if (limit == 12)
            {
                height = 20;
            }
            else
            {
                height = 15;
            }
        }

        private void flwOrder_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flwOrder_ControlAdded(object sender, ControlEventArgs e)
        {
            double price = flwOrder.Controls.Count * 11.5;
            string textPrice = price.ToString("n2");
            lblPrice.Text = '₱' + textPrice;
        }

        private void flwOrder_ControlRemoved(object sender, ControlEventArgs e)
        {
            double price = flwOrder.Controls.Count * 11.5;
            string textPrice = price.ToString("n2");
            lblPrice.Text = '₱' + textPrice;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
