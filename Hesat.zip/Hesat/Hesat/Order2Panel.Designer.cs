﻿namespace Hesat
{
    partial class Order2Panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Order2Panel));
            this.pctWaves = new System.Windows.Forms.PictureBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStrawberry = new System.Windows.Forms.Button();
            this.flwOrder = new System.Windows.Forms.FlowLayoutPanel();
            this.btnWatermelon = new System.Windows.Forms.Button();
            this.btnMango = new System.Windows.Forms.Button();
            this.btnGrapes = new System.Windows.Forms.Button();
            this.btnOrange = new System.Windows.Forms.Button();
            this.btnCookies = new System.Windows.Forms.Button();
            this.btnBiscoff = new System.Windows.Forms.Button();
            this.btnWafer = new System.Windows.Forms.Button();
            this.btnChocolate = new System.Windows.Forms.Button();
            this.btnCandy = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).BeginInit();
            this.SuspendLayout();
            // 
            // pctWaves
            // 
            this.pctWaves.Image = ((System.Drawing.Image)(resources.GetObject("pctWaves.Image")));
            this.pctWaves.Location = new System.Drawing.Point(0, 572);
            this.pctWaves.Name = "pctWaves";
            this.pctWaves.Size = new System.Drawing.Size(1179, 102);
            this.pctWaves.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctWaves.TabIndex = 7;
            this.pctWaves.TabStop = false;
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNext.Location = new System.Drawing.Point(234, 556);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(200, 50);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnBack.Location = new System.Drawing.Point(28, 556);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(200, 50);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Chilanka", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(262, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(647, 94);
            this.label3.TabIndex = 14;
            this.label3.Text = "Customize your order!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label2.Location = new System.Drawing.Point(476, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 34);
            this.label2.TabIndex = 16;
            this.label2.Text = "FLAVORS:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label1.Location = new System.Drawing.Point(476, 341);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 34);
            this.label1.TabIndex = 17;
            this.label1.Text = "TOPPINGS:";
            // 
            // btnStrawberry
            // 
            this.btnStrawberry.Location = new System.Drawing.Point(482, 227);
            this.btnStrawberry.Name = "btnStrawberry";
            this.btnStrawberry.Size = new System.Drawing.Size(105, 73);
            this.btnStrawberry.TabIndex = 18;
            this.btnStrawberry.UseVisualStyleBackColor = true;
            this.btnStrawberry.Click += new System.EventHandler(this.btnStrawberry_Click);
            // 
            // flwOrder
            // 
            this.flwOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flwOrder.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.flwOrder.Font = new System.Drawing.Font("Chilanka", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flwOrder.Location = new System.Drawing.Point(134, 168);
            this.flwOrder.Name = "flwOrder";
            this.flwOrder.Size = new System.Drawing.Size(300, 300);
            this.flwOrder.TabIndex = 19;
            this.flwOrder.Paint += new System.Windows.Forms.PaintEventHandler(this.flwOrder_Paint);
            // 
            // btnWatermelon
            // 
            this.btnWatermelon.Location = new System.Drawing.Point(604, 227);
            this.btnWatermelon.Name = "btnWatermelon";
            this.btnWatermelon.Size = new System.Drawing.Size(105, 73);
            this.btnWatermelon.TabIndex = 20;
            this.btnWatermelon.UseVisualStyleBackColor = true;
            this.btnWatermelon.Click += new System.EventHandler(this.btnWatermelon_Click);
            // 
            // btnMango
            // 
            this.btnMango.Location = new System.Drawing.Point(727, 227);
            this.btnMango.Name = "btnMango";
            this.btnMango.Size = new System.Drawing.Size(105, 73);
            this.btnMango.TabIndex = 21;
            this.btnMango.UseVisualStyleBackColor = true;
            this.btnMango.Click += new System.EventHandler(this.btnMango_Click);
            // 
            // btnGrapes
            // 
            this.btnGrapes.Location = new System.Drawing.Point(851, 227);
            this.btnGrapes.Name = "btnGrapes";
            this.btnGrapes.Size = new System.Drawing.Size(105, 73);
            this.btnGrapes.TabIndex = 22;
            this.btnGrapes.UseVisualStyleBackColor = true;
            this.btnGrapes.Click += new System.EventHandler(this.btnGrapes_Click);
            // 
            // btnOrange
            // 
            this.btnOrange.Location = new System.Drawing.Point(975, 227);
            this.btnOrange.Name = "btnOrange";
            this.btnOrange.Size = new System.Drawing.Size(105, 73);
            this.btnOrange.TabIndex = 23;
            this.btnOrange.UseVisualStyleBackColor = true;
            this.btnOrange.Click += new System.EventHandler(this.btnOrange_Click);
            // 
            // btnCookies
            // 
            this.btnCookies.Location = new System.Drawing.Point(482, 395);
            this.btnCookies.Name = "btnCookies";
            this.btnCookies.Size = new System.Drawing.Size(105, 73);
            this.btnCookies.TabIndex = 24;
            this.btnCookies.UseVisualStyleBackColor = true;
            this.btnCookies.Click += new System.EventHandler(this.btnCookies_Click);
            // 
            // btnBiscoff
            // 
            this.btnBiscoff.Location = new System.Drawing.Point(604, 395);
            this.btnBiscoff.Name = "btnBiscoff";
            this.btnBiscoff.Size = new System.Drawing.Size(105, 73);
            this.btnBiscoff.TabIndex = 25;
            this.btnBiscoff.UseVisualStyleBackColor = true;
            this.btnBiscoff.Click += new System.EventHandler(this.btnBiscoff_Click);
            // 
            // btnWafer
            // 
            this.btnWafer.Location = new System.Drawing.Point(727, 395);
            this.btnWafer.Name = "btnWafer";
            this.btnWafer.Size = new System.Drawing.Size(105, 73);
            this.btnWafer.TabIndex = 26;
            this.btnWafer.UseVisualStyleBackColor = true;
            this.btnWafer.Click += new System.EventHandler(this.btnWafer_Click);
            // 
            // btnChocolate
            // 
            this.btnChocolate.Location = new System.Drawing.Point(851, 395);
            this.btnChocolate.Name = "btnChocolate";
            this.btnChocolate.Size = new System.Drawing.Size(105, 73);
            this.btnChocolate.TabIndex = 27;
            this.btnChocolate.UseVisualStyleBackColor = true;
            this.btnChocolate.Click += new System.EventHandler(this.btnChocolate_Click);
            // 
            // btnCandy
            // 
            this.btnCandy.Location = new System.Drawing.Point(975, 395);
            this.btnCandy.Name = "btnCandy";
            this.btnCandy.Size = new System.Drawing.Size(105, 73);
            this.btnCandy.TabIndex = 28;
            this.btnCandy.UseVisualStyleBackColor = true;
            this.btnCandy.Click += new System.EventHandler(this.btnCandy_Click);
            // 
            // Order2Panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.btnCandy);
            this.Controls.Add(this.btnChocolate);
            this.Controls.Add(this.btnWafer);
            this.Controls.Add(this.btnBiscoff);
            this.Controls.Add(this.btnCookies);
            this.Controls.Add(this.btnOrange);
            this.Controls.Add(this.btnGrapes);
            this.Controls.Add(this.btnMango);
            this.Controls.Add(this.btnWatermelon);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.flwOrder);
            this.Controls.Add(this.btnStrawberry);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pctWaves);
            this.Name = "Order2Panel";
            this.Text = "Order2Panel";
            this.Load += new System.EventHandler(this.Order2Panel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pctWaves;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStrawberry;
        private System.Windows.Forms.FlowLayoutPanel flwOrder;
        private System.Windows.Forms.Button btnWatermelon;
        private System.Windows.Forms.Button btnMango;
        private System.Windows.Forms.Button btnGrapes;
        private System.Windows.Forms.Button btnOrange;
        private System.Windows.Forms.Button btnCookies;
        private System.Windows.Forms.Button btnBiscoff;
        private System.Windows.Forms.Button btnWafer;
        private System.Windows.Forms.Button btnChocolate;
        private System.Windows.Forms.Button btnCandy;
    }
}