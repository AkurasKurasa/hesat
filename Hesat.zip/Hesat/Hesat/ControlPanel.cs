﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hesat
{
    public partial class ControlPanel : Form
    {
        public ControlPanel()
        {
            InitializeComponent();
        }

        string dataPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/orders.txt";
        //string temporaryPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/temporary.txt";
        private string countPath = "C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/count.txt";
        private string blankPath = "C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/blank.txt";
        string chosenId = "";

        private void ControlPanel_Load(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(dataPath))
            {
                String[] entries = sr.ReadToEnd().Split('>');

                for (int i = 0; i < entries.Length - 1; i++)
                {
                    String[] data = entries[i].Split(',');

                    string[] items = { data[3], data[0], data[1], data[5], data[4], data[2], data[4] };
                    ListViewItem lvi = new ListViewItem(items);

                    lstOrders.Items.Add(lvi);

                }

            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int count = 0;

            using (StreamReader sr = new StreamReader(countPath))
            {
                int cnt = int.Parse(sr.ReadLine());
                count = cnt + 1;
            }

            using (StreamWriter sw = new StreamWriter(countPath))
            {
                sw.Write(count);
            }
            EditPanel editPanel = new EditPanel($"#{count}");
            editPanel.Show();
        }

        private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstOrders.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lstOrders.SelectedItems[0];

                string selectedOrder = selectedItem.Text;

                chosenId = selectedOrder;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            String[] entries;

            using (StreamReader sr = new StreamReader(dataPath))
            {
                entries = sr.ReadToEnd().Split('>');
                MessageBox.Show(entries.ToString());
            }

            using (StreamWriter sw = new StreamWriter(dataPath))
            {

                for (int i = 0; i < entries.Length - 1; i++)
                {
                    String[] data = entries[i].Split(',');
                    string Id = data[3];

                    if (chosenId != Id)
                    {

                        sw.WriteLine($"{data[0].Trim()}, {data[1].Trim()}, {data[2].Trim()}, {data[3].Trim()}, {data[4].Trim()}, {data[5].Trim()}, {data[6].Trim()}, {data[7]} >".Trim());

                    }
                  
                }

            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if ( !(chosenId == "") )
            {
                EditPanel editPanel = new EditPanel(chosenId);
                editPanel.Show();
            } else {
                MessageBox.Show("Pick an item!");
            }


        }

        private void btnView_Click(object sender, EventArgs e)
        {
            lstOrders.Items.Clear();

            using (StreamReader sr = new StreamReader(dataPath))
            {
                String[] entries = sr.ReadToEnd().Split('>');

                for (int i = 0; i < entries.Length - 1; i++)
                {
                    String[] data = entries[i].Split(',');

                    string[] items = { data[3].Trim(), data[0].Trim(), data[1].Trim(), data[5].Trim(), data[4].Trim(), data[2].Trim(), data[4].Trim() };
                    ListViewItem lvi = new ListViewItem(items);

                    lstOrders.Items.Add(lvi);

                }

            }
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            lstOrders.Items.Clear();

            string query = txtSearch.Text;

            String[] entries;

            using (StreamReader sr = new StreamReader(dataPath))
            {
                entries = sr.ReadToEnd().Split('>');
            }

            for (int i = 0; i < entries.Length - 1; i++)
            {
                if (entries[i].Contains(query))
                {
                    String[] data = entries[i].Split(',');

                    string[] items = { data[3].Trim(), data[0].Trim(), data[1].Trim(), data[5].Trim(), data[4].Trim(), data[2].Trim(), data[4].Trim() };
                    ListViewItem lvi = new ListViewItem(items);

                    lstOrders.Items.Add(lvi);
                }
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            AdminPanel admin = new AdminPanel();
            admin.Show();
            Visible = false;
        }
    }
}
