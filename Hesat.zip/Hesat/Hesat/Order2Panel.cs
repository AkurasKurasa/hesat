﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class Order2Panel : Form
    {
        //Dictionary<string, string> data = new Dictionary<string, string>();
        int limit = 0;
        int height = 0;

        public Order2Panel(Customer customer = null)
        {
            InitializeComponent();
            btnBack.FlatAppearance.BorderSize = 2;
            btnBack.FlatAppearance.BorderColor = Color.FromArgb(222, 142, 211);

            btnNext.FlatAppearance.BorderSize = 2;
            btnNext.FlatAppearance.BorderColor = Color.White;

            btnStrawberry.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/strawberry.png");
            btnWatermelon.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/watermelon.png");
            btnMango.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/mango.png");
            btnGrapes.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/grapes.png");
            btnOrange.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/orange.png");

            btnCookies.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/cookies.png");
            btnWafer.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/wafer.png");
            btnChocolate.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/chocolate.png");
            btnBiscoff.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/biscoff.png");
            btnCandy.Image = Image.FromFile("C:/Users/paula/OneDrive/Desktop/Hesat/candy.png");

            flwOrder.WrapContents = false;

            current = customer;
        }

        Customer current;

        private void btnBack_Click(object sender, EventArgs e)
        {
            OrderPanel orderPanel = new OrderPanel(current);
            orderPanel.Show();

            Visible = false;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (flwOrder.Controls.Count > 0)
            {
                ArrayList flavors = new ArrayList();
                double price = 0;
                string orders = "END:";

                foreach (Control control in flwOrder.Controls)
                {
                    // Check if the control is a Label
                    if (control is Label label)
                    {
                        // Access the Text property of the Label
                        string labelText = label.Text;
                        flavors.Add(labelText); // Display or process the text
                        price++;
                        orders += $"{labelText}:";
                    }
                }

                current.Order.OrderLayers = orders;
                current.Order.Price = (price * 11.5).ToString("n2");

                Order3Panel orderPanel = new Order3Panel(current);
                orderPanel.Show();
                Visible = false;
            } else
            {
                MessageBox.Show("Please fill your cup!");
            }
        }

        private void Order2Panel_Load(object sender, EventArgs e)
        {
            if (current.Order.CupSize == "6 oz")
            {
                limit = 6;
                height = 40;
            }
            else if (current.Order.CupSize == "8 oz")
            {
                limit = 8;
                height = 30;
            }
            else if (current.Order.CupSize == "12 oz")
            {
                limit = 12;
                height = 20;
            }
            else
            {
                limit = 16;
                height = 15;
            }
        }

        private void btnStrawberry_Click(object sender, EventArgs e)
        {
            
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "STRAWBERRY";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(190, 86, 131);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnWatermelon_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "WATERMELON";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(227, 115, 131);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnMango_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "MANGO";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(255, 195, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnGrapes_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "GRAPES";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(111, 45, 168);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnOrange_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "ORANGE";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(255, 140, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnCookies_Click(object sender, EventArgs e)
        {
 
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "COOKIES";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(187, 136, 85);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnBiscoff_Click(object sender, EventArgs e)
        {
 
            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "BISCOFF";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(224, 163, 121);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnWafer_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "WAFER";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(228, 192, 141);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnChocolate_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "CHOCOLATE";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(123, 63, 0);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void btnCandy_Click(object sender, EventArgs e)
        {

            if (flwOrder.Controls.Count < limit)
            {

                Label lb = new Label();
                lb.Size = new System.Drawing.Size(243, height);
                lb.Margin = new Padding(0, 0, 0, 0);
                lb.Text = "CANDY";
                lb.TextAlign = ContentAlignment.MiddleCenter;
                lb.BorderStyle = BorderStyle.FixedSingle;
                lb.BackColor = Color.FromArgb(0, 191, 255);
                lb.ForeColor = Color.White;
                lb.Cursor = Cursors.Hand;
                lb.Click += (object lblSender, EventArgs lblE) =>
                {
                    Control label = (Control)lblSender;
                    label.Parent.Controls.Remove(label);
                };

                flwOrder.Controls.Add(lb);
            }
        }

        private void flwOrder_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}