﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class CheckPanel : Form
    {
        public CheckPanel()
        {
            InitializeComponent();
        }

        string dataPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/orders.txt";

        private void CheckPanel_Click(object sender, EventArgs e)
        {

        }

        private void CheckPanel_Load(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            LandingPanel landing = new LandingPanel();
            landing.Show();
            Visible = false;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string query = txtID.Text.Trim();

            String[] entries;

            using (StreamReader sr = new StreamReader(dataPath))
            {
                entries = sr.ReadToEnd().Split('>');
            }

            for (int i = 0; i < entries.Length - 1; i++)
            {
                String[] data = entries[i].Split(',');
                if ( query == data[3].Trim() )
                {
                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;
                    label8.Visible = true; 

                    label4.Visible = true;
                    label4.Text = data[4].Trim();

                    lblName.Visible = true;
                    lblName.Text = data[0].Trim();

                    lblNumber.Visible = true;
                    lblNumber.Text = data[1].Trim();

                    lblOrder.Visible = true;
                    lblOrder.Text = data[3].Trim();

                    lblPrice.Visible = true;
                    lblPrice.Text = data[2].Trim();
                }
                
            }
        }

        private void txtID_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtID.ForeColor = Color.Black;
        }
    }
}
