﻿namespace Hesat
{
    partial class OrderPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderPanel));
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pctWaves = new System.Windows.Forms.PictureBox();
            this.btnSixteen = new System.Windows.Forms.Button();
            this.btnTwelve = new System.Windows.Forms.Button();
            this.btnEight = new System.Windows.Forms.Button();
            this.btnSix = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnBack.Location = new System.Drawing.Point(24, 549);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(200, 50);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNext.Location = new System.Drawing.Point(230, 549);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(200, 50);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Chilanka", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(380, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(441, 94);
            this.label3.TabIndex = 13;
            this.label3.Text = "Pick a cup size!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cherry Bomb One", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label1.Location = new System.Drawing.Point(172, 390);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 44);
            this.label1.TabIndex = 14;
            this.label1.Text = "6 oz";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cherry Bomb One", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label2.Location = new System.Drawing.Point(432, 390);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 44);
            this.label2.TabIndex = 15;
            this.label2.Text = "8 oz";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cherry Bomb One", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label4.Location = new System.Drawing.Point(678, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 44);
            this.label4.TabIndex = 16;
            this.label4.Text = "12 oz";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cherry Bomb One", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label5.Location = new System.Drawing.Point(937, 390);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 44);
            this.label5.TabIndex = 17;
            this.label5.Text = "16 oz";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Cherry Swash", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(76, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 23);
            this.label6.TabIndex = 19;
            this.label6.Text = "Hesat";
            // 
            // pctWaves
            // 
            this.pctWaves.Image = ((System.Drawing.Image)(resources.GetObject("pctWaves.Image")));
            this.pctWaves.Location = new System.Drawing.Point(0, 572);
            this.pctWaves.Name = "pctWaves";
            this.pctWaves.Size = new System.Drawing.Size(1179, 102);
            this.pctWaves.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctWaves.TabIndex = 12;
            this.pctWaves.TabStop = false;
            // 
            // btnSixteen
            // 
            this.btnSixteen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSixteen.Image = global::Hesat.Properties.Resources.size_156;
            this.btnSixteen.Location = new System.Drawing.Point(905, 183);
            this.btnSixteen.Name = "btnSixteen";
            this.btnSixteen.Size = new System.Drawing.Size(155, 204);
            this.btnSixteen.TabIndex = 11;
            this.btnSixteen.UseVisualStyleBackColor = true;
            this.btnSixteen.Click += new System.EventHandler(this.btnSixteen_Click);
            // 
            // btnTwelve
            // 
            this.btnTwelve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTwelve.Image = global::Hesat.Properties.Resources.size_144;
            this.btnTwelve.Location = new System.Drawing.Point(636, 183);
            this.btnTwelve.Name = "btnTwelve";
            this.btnTwelve.Size = new System.Drawing.Size(162, 204);
            this.btnTwelve.TabIndex = 10;
            this.btnTwelve.UseVisualStyleBackColor = true;
            this.btnTwelve.Click += new System.EventHandler(this.btnTwelve_Click);
            // 
            // btnEight
            // 
            this.btnEight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEight.Image = global::Hesat.Properties.Resources.size_126;
            this.btnEight.Location = new System.Drawing.Point(386, 183);
            this.btnEight.Name = "btnEight";
            this.btnEight.Size = new System.Drawing.Size(162, 204);
            this.btnEight.TabIndex = 9;
            this.btnEight.UseVisualStyleBackColor = true;
            this.btnEight.Click += new System.EventHandler(this.btnEight_Click);
            // 
            // btnSix
            // 
            this.btnSix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSix.Image = ((System.Drawing.Image)(resources.GetObject("btnSix.Image")));
            this.btnSix.Location = new System.Drawing.Point(131, 183);
            this.btnSix.Name = "btnSix";
            this.btnSix.Size = new System.Drawing.Size(162, 204);
            this.btnSix.TabIndex = 8;
            this.btnSix.UseVisualStyleBackColor = true;
            this.btnSix.Click += new System.EventHandler(this.btnSix_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Chilanka", 1.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(79, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 5);
            this.label7.TabIndex = 20;
            this.label7.Text = "Yogurt that makes you go!";
            // 
            // OrderPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pctWaves);
            this.Controls.Add(this.btnSixteen);
            this.Controls.Add(this.btnTwelve);
            this.Controls.Add(this.btnEight);
            this.Controls.Add(this.btnSix);
            this.Name = "OrderPanel";
            this.Text = "Order";
            this.Load += new System.EventHandler(this.OrderPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnSixteen;
        private System.Windows.Forms.Button btnTwelve;
        private System.Windows.Forms.Button btnEight;
        private System.Windows.Forms.Button btnSix;
        private System.Windows.Forms.PictureBox pctWaves;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}