﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class OrderPanel : Form
    {

        public OrderPanel(Customer customer = null)
        {
            InitializeComponent();
            btnSix.FlatAppearance.BorderSize = 0;
            btnEight.FlatAppearance.BorderSize = 0;
            btnTwelve.FlatAppearance.BorderSize = 0;
            btnSixteen.FlatAppearance.BorderSize = 0;

            btnBack.FlatAppearance.BorderSize = 2;
            btnBack.FlatAppearance.BorderColor = Color.FromArgb(222, 142, 211);

            btnNext.FlatAppearance.BorderSize = 2;
            btnNext.FlatAppearance.BorderColor = Color.White;

            current = customer;
        }

        Customer current;

    private void btnBack_Click(object sender, EventArgs e)
        {
            NavigationPanel navigationPanel = new NavigationPanel();
            navigationPanel.Show();
            Visible = false;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            
            if (current.Order.CupSize != "")
            {
                Order2Panel next = new Order2Panel(current);
                next.Show();

                Visible = false;
            } else
            {
                MessageBox.Show("Please pick a cup size!");
            }
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            current.Order.CupSize = "6 oz";
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            current.Order.CupSize = "8 oz";
        }

        private void btnTwelve_Click(object sender, EventArgs e)
        {
            current.Order.CupSize = "12 oz";
        }

        private void btnSixteen_Click(object sender, EventArgs e)
        {
            current.Order.CupSize = "16 oz";
        }

        private void OrderPanel_Load(object sender, EventArgs e)
        {
          
        }
    }
}
