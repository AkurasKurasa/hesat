﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Hesat
{
    public partial class AdminPanel : Form
    {
        public AdminPanel(Admin admin = null)
        {
            InitializeComponent();
            current = admin;
        }

        Admin current;

        string adminsPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/admins.txt";

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string password = txtPassword.Text;
            bool success = current.Validate(username, password);

            if (success) 
            {
                ControlPanel controlPanel = new ControlPanel();
                controlPanel.Show();
                Visible = false;
            } else { 
                MessageBox.Show("Invalid username or password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
        }
    }
}
