﻿namespace Hesat
{
    partial class Order3Panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Order3Panel));
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblOrderNumber = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.chckCounter = new System.Windows.Forms.CheckBox();
            this.pctPayMaya = new System.Windows.Forms.PictureBox();
            this.pctGcash = new System.Windows.Forms.PictureBox();
            this.pctWaves = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctPayMaya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGcash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnBack.Location = new System.Drawing.Point(20, 559);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(200, 50);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Cherry Bomb One", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNext.Location = new System.Drawing.Point(226, 559);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(200, 50);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // txtName
            // 
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(168, 260);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(482, 30);
            this.txtName.TabIndex = 4;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtNumber
            // 
            this.txtNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumber.Location = new System.Drawing.Point(168, 338);
            this.txtNumber.Multiline = true;
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(482, 30);
            this.txtNumber.TabIndex = 5;
            this.txtNumber.TextChanged += new System.EventHandler(this.txtNumber_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Chilanka", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(345, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(522, 94);
            this.label3.TabIndex = 14;
            this.label3.Text = "Order processed!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Chilanka", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(535, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 32);
            this.label1.TabIndex = 15;
            this.label1.Text = "One last thing...";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cherry Bomb One", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label2.Location = new System.Drawing.Point(176, 231);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 26);
            this.label2.TabIndex = 16;
            this.label2.Text = "NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cherry Bomb One", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label4.Location = new System.Drawing.Point(176, 309);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(156, 26);
            this.label4.TabIndex = 17;
            this.label4.Text = "PHONE NUMBER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cherry Bomb One", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label5.Location = new System.Drawing.Point(176, 397);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 25);
            this.label5.TabIndex = 18;
            this.label5.Text = "ORDER NUMBER";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cherry Bomb One", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label6.Location = new System.Drawing.Point(436, 397);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 25);
            this.label6.TabIndex = 19;
            this.label6.Text = "TOTAL";
            // 
            // lblOrderNumber
            // 
            this.lblOrderNumber.AutoSize = true;
            this.lblOrderNumber.Font = new System.Drawing.Font("Cherry Bomb One", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.lblOrderNumber.Location = new System.Drawing.Point(176, 423);
            this.lblOrderNumber.Name = "lblOrderNumber";
            this.lblOrderNumber.Size = new System.Drawing.Size(89, 25);
            this.lblOrderNumber.TabIndex = 20;
            this.lblOrderNumber.Text = "#000000";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Cherry Bomb One", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(142)))), ((int)(((byte)(211)))));
            this.lblPrice.Location = new System.Drawing.Point(436, 422);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(64, 25);
            this.lblPrice.TabIndex = 21;
            this.lblPrice.Text = "₱0.00";
            // 
            // chckCounter
            // 
            this.chckCounter.AutoSize = true;
            this.chckCounter.Font = new System.Drawing.Font("Chilanka", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckCounter.Location = new System.Drawing.Point(534, 309);
            this.chckCounter.Name = "chckCounter";
            this.chckCounter.Size = new System.Drawing.Size(116, 24);
            this.chckCounter.TabIndex = 22;
            this.chckCounter.Text = "Pay at counter";
            this.chckCounter.UseVisualStyleBackColor = true;
            this.chckCounter.CheckedChanged += new System.EventHandler(this.chckCounter_CheckedChanged);
            // 
            // pctPayMaya
            // 
            this.pctPayMaya.Image = global::Hesat.Properties.Resources.paymaya;
            this.pctPayMaya.Location = new System.Drawing.Point(723, 246);
            this.pctPayMaya.Name = "pctPayMaya";
            this.pctPayMaya.Size = new System.Drawing.Size(144, 144);
            this.pctPayMaya.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctPayMaya.TabIndex = 24;
            this.pctPayMaya.TabStop = false;
            this.pctPayMaya.Click += new System.EventHandler(this.pctPayMaya_Click);
            // 
            // pctGcash
            // 
            this.pctGcash.Image = global::Hesat.Properties.Resources.gcash;
            this.pctGcash.Location = new System.Drawing.Point(873, 246);
            this.pctGcash.Name = "pctGcash";
            this.pctGcash.Size = new System.Drawing.Size(144, 144);
            this.pctGcash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctGcash.TabIndex = 23;
            this.pctGcash.TabStop = false;
            this.pctGcash.Click += new System.EventHandler(this.pctGcash_Click);
            // 
            // pctWaves
            // 
            this.pctWaves.Image = ((System.Drawing.Image)(resources.GetObject("pctWaves.Image")));
            this.pctWaves.Location = new System.Drawing.Point(0, 572);
            this.pctWaves.Name = "pctWaves";
            this.pctWaves.Size = new System.Drawing.Size(1179, 102);
            this.pctWaves.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctWaves.TabIndex = 6;
            this.pctWaves.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cherry Bomb One", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(45)))), ((int)(((byte)(32)))));
            this.label9.Location = new System.Drawing.Point(792, 397);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(161, 25);
            this.label9.TabIndex = 25;
            this.label9.Text = "PLEASE PAY HERE";
            // 
            // Order3Panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pctPayMaya);
            this.Controls.Add(this.pctGcash);
            this.Controls.Add(this.chckCounter);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblOrderNumber);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pctWaves);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.txtName);
            this.Name = "Order3Panel";
            this.Text = "Order3Panel";
            this.Load += new System.EventHandler(this.Order3Panel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctPayMaya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGcash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.PictureBox pctWaves;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblOrderNumber;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.CheckBox chckCounter;
        private System.Windows.Forms.PictureBox pctGcash;
        private System.Windows.Forms.PictureBox pctPayMaya;
        private System.Windows.Forms.Label label9;
    }
}