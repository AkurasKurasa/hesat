﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class NavigationPanel : Form
    {
        public NavigationPanel()
        {
            InitializeComponent();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            OrderPanel orderPanel = new OrderPanel(customer);
            orderPanel.Show();

            Visible = false;
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            AdminPanel adminPanel = new AdminPanel(admin);
            adminPanel.Show();
            Visible = false;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            CheckPanel checkPanel = new CheckPanel();
            checkPanel.Show();
            Visible = false;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LandingPanel landingPanel = new LandingPanel();
            landingPanel.Show();
            Visible = false;
        }
    }
}
