﻿namespace Hesat
{
    partial class LandingPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LandingPanel));
            this.label1 = new System.Windows.Forms.Label();
            this.lblClick = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pctWaves = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cherry Swash", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(441, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(398, 159);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hesat";
            // 
            // lblClick
            // 
            this.lblClick.BackColor = System.Drawing.Color.Transparent;
            this.lblClick.Location = new System.Drawing.Point(0, 1);
            this.lblClick.Name = "lblClick";
            this.lblClick.Size = new System.Drawing.Size(1182, 673);
            this.lblClick.TabIndex = 1;
            this.lblClick.Click += new System.EventHandler(this.lblClick_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Caveat", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(408, 449);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(353, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "Click anywhere to start ordering!";
            // 
            // pctWaves
            // 
            this.pctWaves.Image = ((System.Drawing.Image)(resources.GetObject("pctWaves.Image")));
            this.pctWaves.Location = new System.Drawing.Point(0, 572);
            this.pctWaves.Name = "pctWaves";
            this.pctWaves.Size = new System.Drawing.Size(1179, 102);
            this.pctWaves.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctWaves.TabIndex = 3;
            this.pctWaves.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Hesat.Properties.Resources.hesat_yogurt__192;
            this.pictureBox1.Location = new System.Drawing.Point(276, 100);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Chilanka", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(494, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(251, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "Yogurt that makes you go!";
            // 
            // LandingPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pctWaves);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblClick);
            this.Name = "LandingPanel";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pctWaves)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblClick;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pctWaves;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
    }
}

