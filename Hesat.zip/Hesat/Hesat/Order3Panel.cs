﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class Order3Panel : Form
    {
        //Dictionary<string, string> data = new Dictionary<string, string>();
        string dataPath = "C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/orders.txt";
        public Order3Panel(Customer customer)
        {
            InitializeComponent();
            current = customer;
        }

        Customer current;

        private void btnBack_Click(object sender, EventArgs e)
        {
            Order2Panel order2Panel = new Order2Panel(current);
            order2Panel.Show();
            Visible = false;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (current.Name == "" || current.Number == "" || current.Order.PaymentMethod == "")
            {
                MessageBox.Show("Please fill all necessary fields!");
            } else {
                StreamWriter sw_data = new StreamWriter(dataPath, append: true);

                string cupSize = current.Order.CupSize;

                string name = current.Name;

                string phoneNumber = current.Number;

                string price = current.Order.Price;
                string orderNumber = current.Order.OrderId;
                string orderStatus = current.Order.OrderStatus;
                string paymentMethod = current.Order.PaymentMethod;
                string order = current.Order.OrderLayers;


                sw_data.WriteLine($"{name}, {phoneNumber}, ₱{price}, {orderNumber}, {orderStatus}, {paymentMethod}, {cupSize}, {order} >");
                sw_data.Close();


                Order4Panel order4Panel = new Order4Panel();
                order4Panel.Show();
                Visible = false;
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            current.Name = txtName.Text;
        }

        private void pctPayMaya_Click(object sender, EventArgs e)
        {
            if (!chckCounter.Checked)
            {
                current.Order.PaymentMethod = "PayMaya";
            }
        }

        private void pctGcash_Click(object sender, EventArgs e)
        {
            if (!chckCounter.Checked)
            {
                current.Order.PaymentMethod = "GCash";
            }
        }

        private void Order3Panel_Load(object sender, EventArgs e)
        {
            lblOrderNumber.Text = current.Order.OrderId;
            lblPrice.Text = $"₱{current.Order.Price}";
        }

        private void chckCounter_CheckedChanged(object sender, EventArgs e)
        {
            if (chckCounter.Checked)
            {
                current.Order.PaymentMethod = "Cash"; 
            } else
            {
                current.Order.PaymentMethod = "";
            }
        }

        private void txtNumber_TextChanged(object sender, EventArgs e)
        {
            current.Number = txtNumber.Text;
        }
    }
}
