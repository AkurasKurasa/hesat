﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Windows.Forms;

namespace Hesat
{
    public class Role
    {
        // Properties common to all roles
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        // Constructor

        public Role() 
        {
            Name = "";
            Email = "";
        }
        public Role(string name, string email, string password)
        {
            Name = name;
            Email = email;
        }

        // Method common to all roles
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Role: {this.GetType().Name}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Email: {Email}");
        }
    }

    public class Customer : Role
    {
        public string Name;
        public string Number;
        public string Email;
        public string Password;
        public Order Order;

        // Constructors

        public Customer()
        {
            Name = "";
            Number = "";
            Email = "";
            Password = "";
            Order = new Order();
        }
        public Customer(string name, string email, string number, string password, Order givenOrder)
            : base(name, email, password)
        {
            this.Name = name;
            this.Email = email;
            this.Number = number;
            this.Password = password;
            this.Order = givenOrder;
        }

        // Override DisplayInfo to include Customer-specific data
        public override void DisplayInfo()
        {
            base.DisplayInfo();
        }
    }

    public class Admin : Role
    {
        public string AdminLevel { get; set; }

        // Constructor

        public Admin()
        {
            Name = "";
            Email = "";
            Password = "";
        }
        public Admin(string name, string email, string password, string adminLevel)
            : base(name, email, password)
        {
            AdminLevel = adminLevel;
            Name = name;
            Email = email;
            Password = password;
        }

        // Override DisplayInfo to include Admin-specific data
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Admin Level: {AdminLevel}");
        }

        public bool Validate(string username, string password)
        {
            
            String[] entries;

            using (StreamReader sr = new StreamReader("C:/Users/paula/source/repos/Hesat/Hesat/bin/Debug/admins.txt"))
            {
                entries = sr.ReadToEnd().Split('>');
            }

            for (int i = 0; i < entries.Length - 1; i++)
            {
                String[] data = entries[i].Split(',');
                string correctUsername = data[0].Trim();
                string correctPassword = data[1].Trim();

                if (username == correctUsername && password == correctPassword) { return true; }
            }

            return false;
        }
    }
}
