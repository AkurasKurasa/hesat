﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesat
{
    public partial class Order4Panel : Form
    {
        public Order4Panel()
        {
            InitializeComponent();
        }

        private void lblClick_Click(object sender, EventArgs e)
        {
            LandingPanel landingPanel = new LandingPanel();
            landingPanel.Show();

            Visible = false;
        }
    }
}
