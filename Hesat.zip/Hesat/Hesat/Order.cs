﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hesat
{
    public class Order
    {
        public string OrderStatus { get; set; }
        public string PaymentMethod { get; set; }
        public string OrderId { get; }
        public string CupSize { get; set; }
        public string Price { get; set; }
        public string OrderLayers { get; set; } 
 
        // Constructor
        public Order() 
        {
            OrderStatus = "IN PROGRESS";
            PaymentMethod = string.Empty;

            OrderId = string.Empty;
            Price = string.Empty; 

            int count = 0;

            using (StreamReader sr = new StreamReader("C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/count.txt"))
            {
                int cnt = int.Parse(sr.ReadLine());
                OrderId = $"#{cnt}";
                count = cnt + 1;
            }

            File.Copy("C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/blank.txt", "C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/count.txt", true);


            using (StreamWriter sw = new StreamWriter("C:/Users//paula/source/repos/Hesat/Hesat/bin/Debug/count.txt"))
            {
                sw.Write(count);
            }

            CupSize = string.Empty;
            OrderLayers = string.Empty;
        }

        public Order(string name, string phoneNumber, string orderStatus, string paymentMethod, string orderId, string cupSize, string orderLayers)
        {
            OrderStatus = orderStatus;
            PaymentMethod = paymentMethod;
            OrderId = orderId;
            CupSize = cupSize;
            OrderLayers = orderLayers;
        }

        // Method to calculate the price
        //public double CalculatePrice()
        //{
        //    double basePrice = 0;

        //    // Determine base price based on cup size
        //    switch (CupSize.ToLower())
        //    {
        //        case "6 oz":
        //            basePrice = 10.00;
        //            break;
        //        case "8 oz":
        //            basePrice = 15.00;
        //            break;
        //        case "12 oz":
        //            basePrice = 18.00;
        //            break;
        //        case "16 oz":
        //            basePrice = 20.00;
        //            break;
        //        default:
        //            throw new ArgumentException("Invalid cup size");
        //    }

        //    double layerCost = OrderLayers.Count * 11.50;

        //    return basePrice + layerCost;
        //}

    }
}
